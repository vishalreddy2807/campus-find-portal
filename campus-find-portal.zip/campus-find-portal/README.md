# Campus Find – College Lost & Found Portal

A full-stack web application built with React, TypeScript, Tailwind CSS, Express.js, and Firebase (Firestore & Authentication) for reporting, searching, verifying, and returning lost and found campus items.

## Local Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure environment variables:
   - Copy `.env.example` to `.env` if needed.
   - Ensure `firebase-applet-config.json` contains your Firebase project configuration.
   - In Firebase Console → Authentication → Sign-in method, enable **Google** and **Email/Password** providers.

3. Run in development mode:
   ```bash
   npm run dev
   ```
   The Express + Vite server runs on `http://localhost:3000`.

4. Build for production:
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```
