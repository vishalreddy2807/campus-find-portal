export type ItemCategory =
  | 'Mobile'
  | 'Laptop'
  | 'ID Card'
  | 'Wallet'
  | 'Books'
  | 'Keys'
  | 'Accessories'
  | 'Other';

export type ItemType = 'lost' | 'found';
export type ItemStatus = 'Lost' | 'Found' | 'Claim Pending' | 'Returned';
export type ModerationStatus = 'approved' | 'pending' | 'rejected';
export type UserRole = 'student' | 'faculty' | 'admin';
export type AccountStatus = 'active' | 'suspended';

export const ITEM_CATEGORIES: ItemCategory[] = [
  'Mobile',
  'Laptop',
  'ID Card',
  'Wallet',
  'Books',
  'Keys',
  'Accessories',
  'Other',
];

export const CAMPUS_LOCATION_ZONES: { zone: string; spots: string[] }[] = [
  {
    zone: 'Main Library',
    spots: [
      'Ground Floor Reading Room',
      '2nd Floor Quiet Study Wing',
      'Digital Media Lab',
      'Front Checkout Desk',
    ],
  },
  {
    zone: 'Engineering & CS Block',
    spots: ['CSE Lab 304', 'Lecture Hall E-102', 'Robotics Workshop', 'Atrium Bench Area'],
  },
  {
    zone: 'Student Commons',
    spots: ['Main Lobby', 'Study Lounge', 'Campus Bookstore', 'Student Union Office'],
  },
  {
    zone: 'Science Laboratories',
    spots: ['Chemistry Wing B2', 'Physics Instrumentation Lab', 'Biology Lecture Theater'],
  },
  {
    zone: 'Cafeteria & Dining',
    spots: ['Central Food Court', 'North Coffee Kiosk', 'Outdoor Courtyard Tables'],
  },
  {
    zone: 'Sports & Recreation',
    spots: ['Indoor Gymnasium', 'Athletics Track Bleachers', 'Swimming Pool Lockers'],
  },
  {
    zone: 'Residence Hostels',
    spots: ['North Hall Reception', 'South Block Common Room', 'Laundry Room'],
  },
  {
    zone: 'Administrative Block',
    spots: ['Registrar Counter', 'Academic Advising Office', 'Campus Security Lost & Found Desk'],
  },
  {
    zone: 'Parking & Gates',
    spots: ['Main North Gate', 'Student Bicycle Rack', 'East Visitor Lot'],
  },
];

export const DEPARTMENTS: string[] = [
  'Computer Science & Engineering',
  'Electronics & Communication',
  'Mechanical Engineering',
  'Civil Engineering',
  'Information Science',
  'Business Administration',
  'Mathematics & Sciences',
  'Architecture & Design',
  'Administration & Staff',
];

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  usn: string;
  department: string;
  contact: string;
  role: UserRole;
  accountStatus: AccountStatus;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CampusItem {
  id: string;
  title: string;
  type: ItemType;
  category: ItemCategory;
  description: string;
  date: string;
  location: string;
  locationZone: string;
  imageUrl: string;
  contactPreference: string;
  status: ItemStatus;
  moderationStatus: ModerationStatus;
  reporterId: string;
  reporterName: string;
  reporterRole: UserRole;
  reporterDepartment: string;
  claimedById: string;
  createdAt?: unknown;
  updatedAt?: unknown;
  isDemoOnly?: boolean;
}

export interface OwnershipClaim {
  id: string;
  itemId: string;
  itemTitle: string;
  itemType: ItemType;
  itemReporterId: string;
  claimantId: string;
  claimantName: string;
  claimantUsn: string;
  claimantDepartment: string;
  proofDescription: string;
  proofImageUrl: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewerNote: string;
  approvedContactInfo: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface InAppMessage {
  id: string;
  itemId: string;
  itemTitle: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  recipientName: string;
  body: string;
  read: boolean;
  createdAt?: unknown;
}

export interface UserNotification {
  id: string;
  userId: string;
  actorId: string;
  type: 'match' | 'claim_received' | 'claim_approved' | 'claim_rejected' | 'message' | 'moderation';
  title: string;
  message: string;
  itemId: string;
  read: boolean;
  createdAt?: unknown;
}

export const HERO_CAMPUS_IMAGE = '/src/assets/images/hero_campus_commons_1795508811415.jpg';

export const SAMPLE_CAMPUS_ITEMS: Omit<CampusItem, 'createdAt' | 'updatedAt'>[] = [
  {
    id: 'sample-laptop-macbook-01',
    title: 'Silver MacBook Air 13-inch with Chem Notes',
    type: 'found',
    category: 'Laptop',
    description:
      'Found left unattended on an oak study table on the 2nd floor quiet wing alongside a spiral notebook. Currently stored safely with the Library Front Checkout Desk.',
    date: '2026-11-22',
    location: '2nd Floor Quiet Study Wing, Table 12',
    locationZone: 'Main Library',
    imageUrl: '/src/assets/images/item_silver_laptop_1795508811851.jpg',
    contactPreference: 'Library Front Checkout Desk or In-App Message',
    status: 'Found',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-staff-1',
    reporterName: 'Prof. Elena Vance',
    reporterRole: 'faculty',
    reporterDepartment: 'Mathematics & Sciences',
    claimedById: '',
  },
  {
    id: 'sample-keys-lanyard-02',
    title: 'Brass Dorm Keys & 16GB USB Drive on Blue Lanyard',
    type: 'found',
    category: 'Keys',
    description:
      'Set of two Yale brass keys and a metallic 16GB USB flash drive clipped to a royal blue woven university lanyard. Picked up near the Engineering Atrium coffee counter.',
    date: '2026-11-23',
    location: 'Atrium Bench Area, Ground Floor',
    locationZone: 'Engineering & CS Block',
    imageUrl: '/src/assets/images/item_keys_lanyard_1795508811762.jpg',
    contactPreference: 'In-App Message or CSE Dept Office',
    status: 'Found',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-student-2',
    reporterName: 'Arjun Nair',
    reporterRole: 'student',
    reporterDepartment: 'Computer Science & Engineering',
    claimedById: '',
  },
  {
    id: 'sample-backpack-navy-03',
    title: 'Navy Canvas College Backpack',
    type: 'lost',
    category: 'Accessories',
    description:
      'Lost my navy blue canvas backpack containing two lab manuals and a blue scientific calculator between morning lectures near Corridor 214.',
    date: '2026-11-21',
    location: 'Outside Room 214 Hallway Bench',
    locationZone: 'Engineering & CS Block',
    imageUrl: '/src/assets/images/item_navy_backpack_1795508811276.jpg',
    contactPreference: 'In-App Message',
    status: 'Lost',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-student-3',
    reporterName: 'Meera Krishnan',
    reporterRole: 'student',
    reporterDepartment: 'Electronics & Communication',
    claimedById: '',
  },
  {
    id: 'sample-headphones-sony-04',
    title: 'Matte Charcoal Wireless Over-Ear Headphones + Case',
    type: 'found',
    category: 'Accessories',
    description:
      'Matte charcoal noise-cancelling over-ear headphones with a heather grey zip carry case left in Lecture Hall E-102 after the 2:00 PM Systems Architecture seminar.',
    date: '2026-11-20',
    location: 'Lecture Hall E-102, Row 4',
    locationZone: 'Engineering & CS Block',
    imageUrl: '/src/assets/images/item_wireless_headphones_1795508811871.jpg',
    contactPreference: 'In-App Message',
    status: 'Claim Pending',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-faculty-4',
    reporterName: 'Dr. Vikram Sethi',
    reporterRole: 'faculty',
    reporterDepartment: 'Computer Science & Engineering',
    claimedById: 'campus-demo-student-5',
  },
  {
    id: 'sample-idcard-student-05',
    title: 'University Student ID Card (2024–2028 Batch)',
    type: 'found',
    category: 'ID Card',
    description:
      'Student smart ID card inside a clear rigid sleeve found near the Central Food Court card terminal. Name obscured for privacy—verify USN to claim.',
    date: '2026-11-19',
    location: 'Central Food Court Counter 2',
    locationZone: 'Cafeteria & Dining',
    imageUrl: '',
    contactPreference: 'Campus Security Lost & Found Desk',
    status: 'Returned',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-staff-1',
    reporterName: 'Campus Security Desk',
    reporterRole: 'faculty',
    reporterDepartment: 'Administration & Staff',
    claimedById: 'campus-demo-student-6',
  },
  {
    id: 'sample-wallet-leather-06',
    title: 'Dark Brown Bifold Leather Wallet',
    type: 'lost',
    category: 'Wallet',
    description:
      'Misplaced my slim dark brown leather wallet near the Indoor Gymnasium locker corridor after evening basketball practice. Contains metro transit pass.',
    date: '2026-11-23',
    location: 'Indoor Gymnasium West Corridor',
    locationZone: 'Sports & Recreation',
    imageUrl: '',
    contactPreference: 'In-App Message',
    status: 'Lost',
    moderationStatus: 'approved',
    reporterId: 'campus-demo-student-2',
    reporterName: 'Rohan Deshmukh',
    reporterRole: 'student',
    reporterDepartment: 'Mechanical Engineering',
    claimedById: '',
  },
];
