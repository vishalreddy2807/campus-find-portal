import React, { useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signOut, type User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import { AdminDashboardView } from './components/AdminDashboardView';
import { AuthModal, ProfileSetupModal } from './components/AuthModal';
import { BrowseView } from './components/BrowseView';
import { ErrorBoundary } from './components/ErrorBoundary';
import { HomeView } from './components/HomeView';
import { ItemDetailModal } from './components/ItemDetailModal';
import { Navbar, type ActivePage } from './components/Navbar';
import { ReportItemView } from './components/ReportItemView';
import { UserDashboardView } from './components/UserDashboardView';
import {
  auth,
  BOOTSTRAP_ADMIN_EMAIL,
  db,
  handleFirestoreError,
  OperationType,
} from './lib/firebase';
import {
  SAMPLE_CAMPUS_ITEMS,
  type CampusItem,
  type InAppMessage,
  type ItemType,
  type OwnershipClaim,
  type UserNotification,
  type UserProfile,
} from './types/campus';

function PortalApp() {
  const [authUser, setAuthUser] = useState<FirebaseUser | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [profileChecked, setProfileChecked] = useState(false);

  const [publicItems, setPublicItems] = useState<CampusItem[]>([]);
  const [myItems, setMyItems] = useState<CampusItem[]>([]);
  const [allAdminItems, setAllAdminItems] = useState<CampusItem[]>([]);
  const [itemsLoaded, setItemsLoaded] = useState(false);

  const [claims, setClaims] = useState<OwnershipClaim[]>([]);
  const [messages, setMessages] = useState<InAppMessage[]>([]);
  const [notifications, setNotifications] = useState<UserNotification[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);

  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [browseType, setBrowseType] = useState<'all' | 'lost' | 'found'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [reportType, setReportType] = useState<ItemType>('lost');
  const [editingItem, setEditingItem] = useState<CampusItem | null>(null);
  const [dashTab, setDashTab] = useState<string>('reports');

  const [selectedItem, setSelectedItem] = useState<CampusItem | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [fatalError, setFatalError] = useState<Error | null>(null);

  if (fatalError) {
    throw fatalError;
  }

  const isBootstrapAdmin = Boolean(
    authUser?.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase() &&
      authUser?.emailVerified
  );
  const isAdmin = Boolean(isBootstrapAdmin || userProfile?.role === 'admin');

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setAuthUser(user);
      setAuthReady(true);
      if (!user) {
        setUserProfile(null);
        setProfileChecked(true);
        setClaims([]);
        setMessages([]);
        setNotifications([]);
        setMyItems([]);
        setAllAdminItems([]);
        setAllUsers([]);
      } else {
        setProfileChecked(false);
      }
    });
    return () => unsub();
  }, []);

  // User profile listener
  useEffect(() => {
    if (!authUser) return;
    const ref = doc(db, 'users', authUser.uid);
    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (snap.exists()) {
          setUserProfile(snap.data() as UserProfile);
        } else {
          setUserProfile(null);
        }
        setProfileChecked(true);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.GET, `users/${authUser.uid}`);
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    return () => unsub();
  }, [authUser]);

  // Public approved items listener
  useEffect(() => {
    const q = query(collection(db, 'items'), where('moderationStatus', '==', 'approved'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs.map((d) => d.data() as CampusItem);
        setPublicItems(list);
        setItemsLoaded(true);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'items');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    return () => unsub();
  }, []);

  // User's own items (including any pending/rejected)
  useEffect(() => {
    if (!authUser) return;
    const q = query(collection(db, 'items'), where('reporterId', '==', authUser.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setMyItems(snap.docs.map((d) => d.data() as CampusItem));
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'items');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    return () => unsub();
  }, [authUser]);

  // Admin: all items & all users
  useEffect(() => {
    if (!authUser || !isAdmin) return;
    const unsubItems = onSnapshot(
      collection(db, 'items'),
      (snap) => {
        setAllAdminItems(snap.docs.map((d) => d.data() as CampusItem));
      },
      () => {
        // Non-bootstrap admins fall back gracefully if rule restricts list
      }
    );
    const unsubUsers = onSnapshot(
      collection(db, 'users'),
      (snap) => {
        setAllUsers(snap.docs.map((d) => d.data() as UserProfile));
      },
      () => {}
    );
    return () => {
      unsubItems();
      unsubUsers();
    };
  }, [authUser, isAdmin]);

  // Auto-seed sample campus items on first bootstrap admin sign-in if database has zero items
  useEffect(() => {
    if (!authUser || !isBootstrapAdmin || !itemsLoaded || publicItems.length > 0) return;
    const seed = async () => {
      for (const sample of SAMPLE_CAMPUS_ITEMS) {
        await setDoc(doc(db, 'items', sample.id), {
          ...sample,
          reporterId: authUser.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        }).catch(() => {});
      }
    };
    void seed();
  }, [authUser, isBootstrapAdmin, itemsLoaded, publicItems.length]);

  // Claims listeners (claimant + reporter, or all for admin)
  useEffect(() => {
    if (!authUser) return;
    if (isBootstrapAdmin) {
      const unsubAll = onSnapshot(
        collection(db, 'claims'),
        (snap) => {
          setClaims(snap.docs.map((d) => d.data() as OwnershipClaim));
        },
        (err) => {
          try {
            handleFirestoreError(err, OperationType.LIST, 'claims');
          } catch (wrapped) {
            setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
          }
        }
      );
      return () => unsubAll();
    }

    let asClaimant: OwnershipClaim[] = [];
    let asReporter: OwnershipClaim[] = [];
    const merge = () => {
      const map = new Map<string, OwnershipClaim>();
      [...asClaimant, ...asReporter].forEach((c) => map.set(c.id, c));
      setClaims(Array.from(map.values()));
    };

    const unsub1 = onSnapshot(
      query(collection(db, 'claims'), where('claimantId', '==', authUser.uid)),
      (snap) => {
        asClaimant = snap.docs.map((d) => d.data() as OwnershipClaim);
        merge();
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'claims');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    const unsub2 = onSnapshot(
      query(collection(db, 'claims'), where('itemReporterId', '==', authUser.uid)),
      (snap) => {
        asReporter = snap.docs.map((d) => d.data() as OwnershipClaim);
        merge();
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'claims');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );

    return () => {
      unsub1();
      unsub2();
    };
  }, [authUser, isBootstrapAdmin]);

  // Messages listeners (sent + received)
  useEffect(() => {
    if (!authUser) return;
    let sent: InAppMessage[] = [];
    let received: InAppMessage[] = [];
    const merge = () => {
      const map = new Map<string, InAppMessage>();
      [...sent, ...received].forEach((m) => map.set(m.id, m));
      setMessages(Array.from(map.values()));
    };

    const unsubSent = onSnapshot(
      query(collection(db, 'messages'), where('senderId', '==', authUser.uid)),
      (snap) => {
        sent = snap.docs.map((d) => d.data() as InAppMessage);
        merge();
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'messages');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    const unsubRecv = onSnapshot(
      query(collection(db, 'messages'), where('recipientId', '==', authUser.uid)),
      (snap) => {
        received = snap.docs.map((d) => d.data() as InAppMessage);
        merge();
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'messages');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );

    return () => {
      unsubSent();
      unsubRecv();
    };
  }, [authUser]);

  // Notifications listener
  useEffect(() => {
    if (!authUser) return;
    const q = query(collection(db, 'notifications'), where('userId', '==', authUser.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setNotifications(snap.docs.map((d) => d.data() as UserNotification));
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, 'notifications');
        } catch (wrapped) {
          setFatalError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      }
    );
    return () => unsub();
  }, [authUser]);

  // Merge visible items (falling back to demo preview items only when Firestore has 0 items)
  const mergedItems = useMemo(() => {
    const map = new Map<string, CampusItem>();
    publicItems.forEach((i) => map.set(i.id, i));
    myItems.forEach((i) => map.set(i.id, i));
    allAdminItems.forEach((i) => map.set(i.id, i));

    if (map.size === 0 && itemsLoaded) {
      return SAMPLE_CAMPUS_ITEMS.map((s) => ({ ...s, isDemoOnly: true }));
    }
    return Array.from(map.values()).sort((a, b) => b.date.localeCompare(a.date));
  }, [publicItems, myItems, allAdminItems, itemsLoaded]);

  const unreadNotifications = notifications.filter((n) => !n.read).length;
  const unreadMessages = authUser
    ? messages.filter((m) => m.recipientId === authUser.uid && !m.read).length
    : 0;

  const handleNavigate = (
    page: ActivePage,
    options?: { reportType?: 'lost' | 'found'; dashTab?: string }
  ) => {
    setActivePage(page);
    setEditingItem(null);
    if (page === 'lost') {
      setBrowseType('lost');
    } else if (page === 'found') {
      setBrowseType('found');
    } else if (page === 'report' && options?.reportType) {
      setReportType(options.reportType);
    } else if (page === 'dashboard' && options?.dashTab) {
      setDashTab(options.dashTab);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (keyword: string, category?: string) => {
    setSearchKeyword(keyword);
    if (category) {
      setCategoryFilter(category);
    }
    setBrowseType('all');
    setActivePage('lost');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setActivePage('home');
  };

  const showProfileSetup = Boolean(authReady && authUser && profileChecked && !userProfile);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900">
      <Navbar
        activePage={activePage}
        onNavigate={handleNavigate}
        userProfile={userProfile}
        isAuthenticated={Boolean(authUser)}
        isAdmin={isAdmin}
        unreadNotifications={unreadNotifications}
        unreadMessages={unreadMessages}
        onOpenAuth={() => setAuthModalOpen(true)}
        onSignOut={() => void handleSignOut()}
      />

      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
          >
            {activePage === 'home' && (
              <HomeView
                items={mergedItems}
                onSearchSubmit={handleSearchSubmit}
                onNavigateBrowse={(type) => handleNavigate(type)}
                onNavigateReport={(type) => handleNavigate('report', { reportType: type })}
                onSelectItem={(item) => setSelectedItem(item)}
              />
            )}

            {(activePage === 'lost' || activePage === 'found') && (
              <BrowseView
                items={mergedItems}
                typeFilter={browseType}
                onTypeFilterChange={(t) => setBrowseType(t)}
                searchKeyword={searchKeyword}
                onSearchKeywordChange={setSearchKeyword}
                categoryFilter={categoryFilter}
                onCategoryFilterChange={setCategoryFilter}
                onSelectItem={(item) => setSelectedItem(item)}
                onNavigateReport={(type) => handleNavigate('report', { reportType: type })}
              />
            )}

            {activePage === 'report' && (
              <ReportItemView
                initialType={reportType}
                editingItem={editingItem}
                existingItems={mergedItems}
                userProfile={userProfile}
                isAuthenticated={Boolean(authUser)}
                onOpenAuth={() => setAuthModalOpen(true)}
                onSuccess={(createdType) => {
                  setEditingItem(null);
                  setBrowseType(createdType);
                  setActivePage(createdType);
                }}
                onCancelEdit={
                  editingItem
                    ? () => {
                        setEditingItem(null);
                        setActivePage('dashboard');
                      }
                    : undefined
                }
              />
            )}

            {activePage === 'dashboard' && (
              <UserDashboardView
                initialTab={dashTab}
                userProfile={userProfile}
                isAuthenticated={Boolean(authUser)}
                items={mergedItems}
                claims={claims}
                messages={messages}
                notifications={notifications}
                onOpenAuth={() => setAuthModalOpen(true)}
                onEditItem={(item) => {
                  setEditingItem(item);
                  setReportType(item.type);
                  setActivePage('report');
                }}
                onSelectItem={(item) => setSelectedItem(item)}
              />
            )}

            {activePage === 'admin' && isAdmin && userProfile && (
              <AdminDashboardView
                adminProfile={userProfile}
                items={mergedItems}
                claims={claims}
                users={allUsers}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <div className="space-y-1">
            <p className="font-display font-semibold text-sm text-slate-900">Campus Find</p>
            <p>
              Centralized College Lost & Found Registry · Personal contact details protected until
              claim verification.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('home')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('lost')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Lost Items
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('found')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Found Items
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('report')}
              className="hover:text-slate-900 cursor-pointer"
            >
              Report Item
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('dashboard')}
              className="hover:text-slate-900 cursor-pointer"
            >
              My Reports
            </button>
            <a
              href="/api/download-zip"
              download="campus-find-portal.zip"
              className="font-medium text-blue-700 hover:text-blue-800 hover:underline whitespace-nowrap"
            >
              Download Project (.zip)
            </a>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />

      {showProfileSetup && authUser && (
        <ProfileSetupModal
          uid={authUser.uid}
          email={authUser.email || ''}
          emailVerified={authUser.emailVerified}
          defaultName={authUser.displayName || ''}
          onComplete={() => setProfileChecked(true)}
        />
      )}

      <ItemDetailModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        userProfile={userProfile}
        isAuthenticated={Boolean(authUser)}
        onOpenAuth={() => {
          setSelectedItem(null);
          setAuthModalOpen(true);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <PortalApp />
    </ErrorBoundary>
  );
}
