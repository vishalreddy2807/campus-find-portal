import React, { useMemo, useState } from 'react';
import { MapPin, RotateCcw, Search } from 'lucide-react';
import {
  CAMPUS_LOCATION_ZONES,
  ITEM_CATEGORIES,
  type CampusItem,
  type ItemStatus,
} from '../types/campus';
import { ItemVisual, StatusLabel } from './ItemVisual';

interface BrowseViewProps {
  items: CampusItem[];
  typeFilter: 'all' | 'lost' | 'found';
  onTypeFilterChange: (type: 'all' | 'lost' | 'found') => void;
  searchKeyword: string;
  onSearchKeywordChange: (val: string) => void;
  categoryFilter: string;
  onCategoryFilterChange: (val: string) => void;
  onSelectItem: (item: CampusItem) => void;
  onNavigateReport: (type: 'lost' | 'found') => void;
}

export const BrowseView: React.FC<BrowseViewProps> = ({
  items,
  typeFilter,
  onTypeFilterChange,
  searchKeyword,
  onSearchKeywordChange,
  categoryFilter,
  onCategoryFilterChange,
  onSelectItem,
  onNavigateReport,
}) => {
  const [zoneFilter, setZoneFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState<'All' | ItemStatus>('All');
  const [dateFrom, setDateFrom] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  const filteredItems = useMemo(() => {
    const kw = searchKeyword.trim().toLowerCase();
    return items
      .filter((item) => item.moderationStatus === 'approved')
      .filter((item) => (typeFilter === 'all' ? true : item.type === typeFilter))
      .filter((item) => (categoryFilter === 'All' ? true : item.category === categoryFilter))
      .filter((item) => (zoneFilter === 'All' ? true : item.locationZone === zoneFilter))
      .filter((item) => (statusFilter === 'All' ? true : item.status === statusFilter))
      .filter((item) => (dateFrom ? item.date >= dateFrom : true))
      .filter((item) => {
        if (!kw) return true;
        return (
          item.title.toLowerCase().includes(kw) ||
          item.description.toLowerCase().includes(kw) ||
          item.category.toLowerCase().includes(kw) ||
          item.location.toLowerCase().includes(kw) ||
          item.locationZone.toLowerCase().includes(kw)
        );
      })
      .sort((a, b) => {
        if (sortOrder === 'newest') {
          return b.date.localeCompare(a.date);
        }
        return a.date.localeCompare(b.date);
      });
  }, [
    items,
    typeFilter,
    categoryFilter,
    zoneFilter,
    statusFilter,
    dateFrom,
    searchKeyword,
    sortOrder,
  ]);

  const resetFilters = () => {
    onSearchKeywordChange('');
    onCategoryFilterChange('All');
    onTypeFilterChange('all');
    setZoneFilter('All');
    setStatusFilter('All');
    setDateFrom('');
    setSortOrder('newest');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900">
            {typeFilter === 'lost'
              ? 'Lost Items Directory'
              : typeFilter === 'found'
              ? 'Found Items Directory'
              : 'All Campus Lost & Found Items'}
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Filter by category, campus building zone, reported date, or status.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg">
            {(['all', 'lost', 'found'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => onTypeFilterChange(t)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  typeFilter === t
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t === 'all' ? 'All Items' : t === 'lost' ? 'Lost' : 'Found'}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => onNavigateReport(typeFilter === 'found' ? 'found' : 'lost')}
            className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            + Report Item
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => onSearchKeywordChange(e.target.value)}
              placeholder="Search keywords, model, color..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          <select
            aria-label="Category filter"
            value={categoryFilter}
            onChange={(e) => onCategoryFilterChange(e.target.value)}
            className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          >
            <option value="All">All Categories</option>
            {ITEM_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <select
            aria-label="Campus zone filter"
            value={zoneFilter}
            onChange={(e) => setZoneFilter(e.target.value)}
            className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          >
            <option value="All">All Campus Zones</option>
            {CAMPUS_LOCATION_ZONES.map((z) => (
              <option key={z.zone} value={z.zone}>
                {z.zone}
              </option>
            ))}
          </select>

          <select
            aria-label="Status filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'All' | ItemStatus)}
            className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          >
            <option value="All">All Statuses</option>
            <option value="Lost">Lost</option>
            <option value="Found">Found</option>
            <option value="Claim Pending">Claim Pending</option>
            <option value="Returned">Returned</option>
          </select>

          <input
            type="date"
            aria-label="Reported on or after date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="px-3 py-2 text-sm font-mono bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs text-slate-500">
          <span className="tabular-nums">
            Showing <strong className="text-slate-900">{filteredItems.length}</strong> matching
            reports
          </span>
          <div className="flex items-center gap-4">
            <label className="inline-flex items-center gap-2">
              <span>Sort:</span>
              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
                className="bg-transparent font-medium text-slate-700 focus:outline-none cursor-pointer"
              >
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
              </select>
            </label>
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1 text-blue-700 hover:underline font-medium cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>
      </div>

      {/* Results Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center space-y-3">
          <h2 className="text-lg font-display font-semibold text-slate-900">
            No matching items found
          </h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Try clearing some filters or search with broader keywords. You can also report an item
            so others on campus can help look for it.
          </p>
          <div className="pt-2 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={resetFilters}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              Clear All Filters
            </button>
            <button
              type="button"
              onClick={() => onNavigateReport('lost')}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
            >
              Report Missing Item
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <article
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="group bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blue-300 transition-colors cursor-pointer flex flex-col"
            >
              <ItemVisual
                imageUrl={item.imageUrl}
                title={item.title}
                category={item.category}
                className="aspect-[4/3] w-full border-b border-slate-100"
              />
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="text-base font-display font-semibold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-2">
                      {item.title}
                    </h3>
                    <StatusLabel status={item.status} />
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                    <span>{item.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{item.date}</span>
                    <span aria-hidden="true">·</span>
                    <span>By {item.reporterName}</span>
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                  <span className="inline-flex items-center gap-1.5 text-xs text-slate-500 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{item.locationZone}</span>
                  </span>
                  <span className="text-xs font-medium text-blue-700 whitespace-nowrap shrink-0">
                    {item.type === 'found' ? 'Claim / Contact →' : 'Contact Owner →'}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
