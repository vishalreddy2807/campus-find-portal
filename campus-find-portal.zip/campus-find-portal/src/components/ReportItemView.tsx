import React, { useEffect, useState } from 'react';
import { addDoc, collection, doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { AlertCircle, CheckCircle2, ImagePlus, Trash2, Upload } from 'lucide-react';
import {
  createRecordId,
  db,
  handleFirestoreError,
  OperationType,
  uploadImageFile,
} from '../lib/firebase';
import {
  CAMPUS_LOCATION_ZONES,
  ITEM_CATEGORIES,
  type CampusItem,
  type ItemCategory,
  type ItemType,
  type UserProfile,
} from '../types/campus';

interface ReportItemViewProps {
  initialType: ItemType;
  editingItem?: CampusItem | null;
  existingItems: CampusItem[];
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  onOpenAuth: () => void;
  onSuccess: (createdType: ItemType) => void;
  onCancelEdit?: () => void;
}

export const ReportItemView: React.FC<ReportItemViewProps> = ({
  initialType,
  editingItem,
  existingItems,
  userProfile,
  isAuthenticated,
  onOpenAuth,
  onSuccess,
  onCancelEdit,
}) => {
  const [type, setType] = useState<ItemType>(editingItem?.type || initialType);
  const [title, setTitle] = useState(editingItem?.title || '');
  const [category, setCategory] = useState<ItemCategory>(editingItem?.category || 'Laptop');
  const [description, setDescription] = useState(editingItem?.description || '');
  const [date, setDate] = useState(
    editingItem?.date || new Date().toISOString().slice(0, 10)
  );
  const [zones, setZones] = useState(CAMPUS_LOCATION_ZONES);
  const [locationZone, setLocationZone] = useState(
    editingItem?.locationZone || CAMPUS_LOCATION_ZONES[0].zone
  );
  const [location, setLocation] = useState(editingItem?.location || '');
  const [imageUrl, setImageUrl] = useState(editingItem?.imageUrl || '');
  const [contactPreference, setContactPreference] = useState(
    editingItem?.contactPreference || 'In-App Message'
  );
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [matchCount, setMatchCount] = useState<number | null>(null);

  useEffect(() => {
    fetch('/api/campus-locations')
      .then((res) => res.json())
      .then((data: { zones?: { zone: string; spots: string[] }[] }) => {
        if (Array.isArray(data.zones) && data.zones.length > 0) {
          setZones(data.zones);
        }
      })
      .catch(() => {
        // Fallback to built-in CAMPUS_LOCATION_ZONES
      });
  }, []);

  useEffect(() => {
    if (!editingItem) {
      setType(initialType);
    }
  }, [initialType, editingItem]);

  const activeZoneSpots =
    zones.find((z) => z.zone === locationZone)?.spots || [];

  const handleImageUpload = async (file: File | undefined) => {
    if (!file) return;
    setError('');
    setUploading(true);
    try {
      const url = await uploadImageFile(file);
      setImageUrl(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload image.');
    } finally {
      setUploading(false);
    }
  };

  const triggerSmartMatchNotifications = async (
    newItemId: string,
    newItemTitle: string,
    newType: ItemType,
    newCategory: ItemCategory,
    newDescription: string
  ) => {
    if (!userProfile) return;
    const oppositeType: ItemType = newType === 'lost' ? 'found' : 'lost';
    const tokens = new Set(
      `${newItemTitle} ${newDescription}`
        .toLowerCase()
        .split(/[^a-z0-9]+/)
        .filter((w) => w.length >= 3)
    );

    const candidates = existingItems.filter(
      (item) =>
        !item.isDemoOnly &&
        item.moderationStatus === 'approved' &&
        item.type === oppositeType &&
        item.status !== 'Returned' &&
        item.reporterId !== userProfile.uid &&
        item.category === newCategory
    );

    const matched = candidates.filter((cand) => {
      const candText = `${cand.title} ${cand.description}`.toLowerCase();
      let overlap = 0;
      tokens.forEach((tok) => {
        if (candText.includes(tok)) overlap += 1;
      });
      return overlap >= 1 || cand.locationZone === locationZone;
    });

    if (matched.length === 0) return;

    const notifiedUsers = new Set<string>();
    for (const match of matched.slice(0, 5)) {
      if (notifiedUsers.has(match.reporterId)) continue;
      notifiedUsers.add(match.reporterId);

      const notifId = createRecordId('notif');
      try {
        await setDoc(doc(db, 'notifications', notifId), {
          id: notifId,
          userId: match.reporterId,
          actorId: userProfile.uid,
          type: 'match',
          title:
            newType === 'found'
              ? `Possible match found: ${newItemTitle.slice(0, 60)}`
              : `Matching lost report posted: ${newItemTitle.slice(0, 60)}`,
          message: `A ${newType} ${newCategory} report near ${locationZone} matches "${match.title}". Inspect it in Campus Find.`,
          itemId: newItemId,
          read: false,
          createdAt: serverTimestamp(),
        });
      } catch {
        // Non-fatal if notification target fails
      }
    }
    setMatchCount(matched.length);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated || !userProfile) {
      onOpenAuth();
      return;
    }
    if (userProfile.accountStatus === 'suspended') {
      setError('Your account is currently suspended. Contact an administrator.');
      return;
    }

    if (title.trim().length < 2 || description.trim().length < 5 || location.trim().length < 2) {
      setError('Please enter a valid item name, description (at least 5 characters), and campus location.');
      return;
    }

    setError('');
    setSubmitting(true);

    try {
      if (editingItem) {
        const ref = doc(db, 'items', editingItem.id);
        await updateDoc(ref, {
          title: title.trim().slice(0, 120),
          type,
          category,
          description: description.trim().slice(0, 1000),
          date: date.slice(0, 20),
          location: location.trim().slice(0, 120),
          locationZone: locationZone.slice(0, 80),
          imageUrl: imageUrl.slice(0, 500),
          contactPreference: contactPreference.trim().slice(0, 120) || 'In-App Message',
          status:
            editingItem.status === 'Claim Pending' || editingItem.status === 'Returned'
              ? editingItem.status
              : type === 'lost'
              ? 'Lost'
              : 'Found',
          updatedAt: serverTimestamp(),
        });
        onSuccess(type);
        return;
      }

      const itemId = createRecordId('item');
      const payload = {
        id: itemId,
        title: title.trim().slice(0, 120),
        type,
        category,
        description: description.trim().slice(0, 1000),
        date: date.slice(0, 20),
        location: location.trim().slice(0, 120),
        locationZone: locationZone.slice(0, 80),
        imageUrl: imageUrl.slice(0, 500),
        contactPreference: contactPreference.trim().slice(0, 120) || 'In-App Message',
        status: type === 'lost' ? 'Lost' : 'Found',
        moderationStatus: 'approved',
        reporterId: userProfile.uid,
        reporterName: userProfile.name.slice(0, 100),
        reporterRole: userProfile.role,
        reporterDepartment: userProfile.department.slice(0, 80),
        claimedById: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      await setDoc(doc(db, 'items', itemId), payload);
      await triggerSmartMatchNotifications(
        itemId,
        payload.title,
        type,
        category,
        payload.description
      );
      onSuccess(type);
    } catch (err) {
      try {
        handleFirestoreError(
          err,
          editingItem ? OperationType.UPDATE : OperationType.CREATE,
          editingItem ? `items/${editingItem.id}` : 'items'
        );
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to submit item report.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16">
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-4">
          <h1 className="text-2xl font-display font-bold text-slate-900">
            Sign in to Report an Item
          </h1>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Only verified students, faculty, and campus staff can submit lost or found reports to
            prevent spam and protect personal belongings.
          </p>
          <button
            type="button"
            onClick={onOpenAuth}
            className="px-5 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
          >
            Login / Register to Continue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-slate-900">
              {editingItem
                ? 'Edit Item Report'
                : type === 'lost'
                ? 'Report a Lost Item'
                : 'Report a Found Item'}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Provide accurate details so Campus Find can match belongings quickly.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setType('lost')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                type === 'lost' ? 'bg-white text-rose-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Lost Item
            </button>
            <button
              type="button"
              onClick={() => setType('found')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                type === 'found' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Found Item
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {matchCount !== null && matchCount > 0 && (
            <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 flex items-start gap-2.5 text-xs text-emerald-800">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <span>
                Report saved! We notified {matchCount} matching campus report(s) automatically.
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Item Name *
              </label>
              <input
                type="text"
                required
                minLength={2}
                maxLength={120}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={
                  type === 'lost'
                    ? 'e.g. Silver MacBook Air 13-inch'
                    : 'e.g. Blue Lanyard with Brass Keys'
                }
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ItemCategory)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              >
                {ITEM_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Item Description *
            </label>
            <textarea
              required
              minLength={5}
              maxLength={1000}
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={
                type === 'lost'
                  ? 'Describe color, brand, stickers, or distinctive marks (avoid posting sensitive serial numbers publicly).'
                  : 'Describe where it was found and general appearance. Keep 1-2 unique details private so the true owner can verify.'
              }
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                {type === 'lost' ? 'Date Lost *' : 'Date Found *'}
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Campus Zone *
              </label>
              <select
                value={locationZone}
                onChange={(e) => setLocationZone(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              >
                {zones.map((z) => (
                  <option key={z.zone} value={z.zone}>
                    {z.zone}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              {type === 'lost' ? 'Specific Location Lost *' : 'Specific Location Found *'}
            </label>
            <input
              type="text"
              required
              minLength={2}
              maxLength={120}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. 2nd Floor Quiet Study Wing, Table 12"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
            {activeZoneSpots.length > 0 && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <span className="text-xs text-slate-500">Quick spots:</span>
                {activeZoneSpots.map((spot) => (
                  <button
                    key={spot}
                    type="button"
                    onClick={() => setLocation(spot)}
                    className="px-2 py-1 text-xs text-slate-700 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 rounded-md transition-colors cursor-pointer"
                  >
                    {spot}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Item Photo (Optional, max 2.5 MB)
            </label>
            {imageUrl ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-3 border border-slate-200 rounded-lg bg-slate-50">
                <img
                  src={imageUrl}
                  alt="Uploaded item preview"
                  referrerPolicy="no-referrer"
                  className="w-32 h-24 object-cover rounded-lg border border-slate-200 bg-white"
                />
                <div className="space-y-2">
                  <p className="text-xs font-medium text-slate-700">Photo attached cleanly</p>
                  <button
                    type="button"
                    onClick={() => setImageUrl('')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-700 bg-white border border-rose-200 hover:bg-rose-50 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Photo</span>
                  </button>
                </div>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center border border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-6 bg-slate-50/70 hover:bg-blue-50/30 transition-colors cursor-pointer">
                <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-blue-700 mb-2">
                  {uploading ? <Upload className="w-5 h-5 animate-bounce" /> : <ImagePlus className="w-5 h-5" />}
                </div>
                <span className="text-sm font-medium text-slate-800">
                  {uploading ? 'Uploading photo...' : 'Click to upload an item photo'}
                </span>
                <span className="text-xs text-slate-500 mt-0.5">
                  PNG, JPG, WEBP, or GIF up to 2.5 MB
                </span>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  className="hidden"
                  disabled={uploading}
                  onChange={(e) => void handleImageUpload(e.target.files?.[0])}
                />
              </label>
            )}
          </div>

          {/* Contact Preference (Safe Campus Handover / In-App Messaging) */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Safe Contact / Handover Desk Preference
            </label>
            <input
              type="text"
              maxLength={120}
              value={contactPreference}
              onChange={(e) => setContactPreference(e.target.value)}
              placeholder="e.g. In-App Message or Main Library Security Desk"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
            />
            <p className="text-xs text-slate-500 mt-1">
              Your personal email and phone number remain hidden until you approve an ownership claim.
            </p>
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            {onCancelEdit && (
              <button
                type="button"
                onClick={onCancelEdit}
                className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              disabled={submitting || uploading}
              className="px-6 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer disabled:opacity-60"
            >
              {submitting
                ? 'Saving Report...'
                : editingItem
                ? 'Save Changes'
                : type === 'lost'
                ? 'Submit Lost Item Report'
                : 'Publish Found Item Report'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
