import React, { useState } from 'react';
import { ArrowRight, MapPin, Search } from 'lucide-react';
import {
  CAMPUS_LOCATION_ZONES,
  HERO_CAMPUS_IMAGE,
  ITEM_CATEGORIES,
  type CampusItem,
} from '../types/campus';
import { ItemVisual, StatusLabel } from './ItemVisual';

interface HomeViewProps {
  items: CampusItem[];
  onSearchSubmit: (keyword: string, category?: string) => void;
  onNavigateBrowse: (type: 'lost' | 'found') => void;
  onNavigateReport: (type: 'lost' | 'found') => void;
  onSelectItem: (item: CampusItem) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  items,
  onSearchSubmit,
  onNavigateBrowse,
  onNavigateReport,
  onSelectItem,
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const approvedItems = items.filter((item) => item.moderationStatus === 'approved');
  const totalLost = approvedItems.filter((item) => item.type === 'lost').length;
  const totalFound = approvedItems.filter((item) => item.type === 'found').length;
  const totalReturned = approvedItems.filter((item) => item.status === 'Returned').length;
  const activeZones = CAMPUS_LOCATION_ZONES.length;

  const recentItems = approvedItems.slice(0, 6);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit(query.trim(), selectedCategory);
  };

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section: Balanced 2-Column Split */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="space-y-3">
                <p className="text-xs font-medium text-blue-700 tracking-wide">
                  Official Campus Recovery Registry
                </p>
                <h1
                  className="font-display font-bold text-slate-900 tracking-tight leading-[1.12] max-w-xl"
                  style={{ fontSize: 'clamp(2.25rem, 4vw, 3.25rem)', textWrap: 'balance' }}
                >
                  Lost Something? Find It Here!
                </h1>
                <p className="text-base text-slate-600 leading-relaxed max-w-xl">
                  A centralized portal for students, faculty, and campus staff to report misplaced
                  belongings, post found items, and verify ownership securely without exposing
                  personal contact details.
                </p>
              </div>

              {/* Search Bar */}
              <form
                onSubmit={handleSubmit}
                className="bg-slate-50 border border-slate-200 rounded-xl p-2 flex flex-col sm:flex-row gap-2 max-w-2xl"
              >
                <div className="relative flex-1 min-w-0">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search laptop, ID card, keys, library..."
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                  />
                </div>
                <select
                  aria-label="Filter by category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                >
                  <option value="All">All Categories</option>
                  {ITEM_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Search Items
                </button>
              </form>

              {/* Action Row */}
              <div className="flex flex-wrap items-center gap-4 pt-1">
                <button
                  type="button"
                  onClick={() => onNavigateReport('lost')}
                  className="px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Report a Lost Item
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateReport('found')}
                  className="px-4 py-2.5 text-sm font-medium text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Post a Found Item
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateBrowse('found')}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Browse Found Registry</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative h-64 sm:h-80 lg:h-full min-h-[280px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                <img
                  src={HERO_CAMPUS_IMAGE}
                  alt="University student commons and library quad"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/75 via-slate-900/15 to-transparent flex items-end p-5">
                  <div className="text-white">
                    <p className="text-xs font-medium text-blue-200">
                      Main Library & Student Commons Hub
                    </p>
                    <p className="text-sm font-medium mt-0.5">
                      Verified handover desks across 9 campus zones
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Full-Width 4-Column Statistics Strip */}
          <div className="mt-10 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="text-xs font-medium text-slate-500">Total Lost Reports</p>
              <p className="mt-1 text-2xl sm:text-3xl font-display font-bold text-slate-900 tabular-nums">
                {totalLost}
              </p>
              <p className="mt-0.5 text-xs text-slate-500">Active student & faculty reports</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total Found Items</p>
              <p className="mt-1 text-2xl sm:text-3xl font-display font-bold text-blue-700 tabular-nums">
                {totalFound}
              </p>
              <p className="mt-0.5 text-xs text-slate-500">Logged for owner verification</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Successfully Returned</p>
              <p className="mt-1 text-2xl sm:text-3xl font-display font-bold text-emerald-700 tabular-nums">
                {totalReturned}
              </p>
              <p className="mt-0.5 text-xs text-slate-500">Verified & handed back</p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Campus Zones Monitored</p>
              <p className="mt-1 text-2xl sm:text-3xl font-display font-bold text-slate-900 tabular-nums">
                {activeZones}
              </p>
              <p className="mt-0.5 text-xs text-slate-500">Libraries, labs, dining & hostels</p>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Lost & Found Items Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl font-display font-bold text-slate-900">
              Recent Campus Reports
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Click any item to inspect location details, contact the reporter safely, or submit an
              ownership claim.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigateBrowse('lost')}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              All Lost Items
            </button>
            <button
              type="button"
              onClick={() => onNavigateBrowse('found')}
              className="px-3.5 py-2 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              All Found Items
            </button>
          </div>
        </div>

        {recentItems.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
            <p className="text-sm text-slate-600">
              No lost or found reports have been published yet.
            </p>
            <button
              type="button"
              onClick={() => onNavigateReport('found')}
              className="mt-4 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
            >
              Post First Report
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentItems.map((item) => (
              <article
                key={item.id}
                onClick={() => onSelectItem(item)}
                className="group bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blue-300 transition-colors cursor-pointer flex flex-col"
              >
                <ItemVisual
                  imageUrl={item.imageUrl}
                  title={item.title}
                  category={item.category}
                  className="aspect-[4/3] w-full border-b border-slate-100"
                />
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="text-base font-display font-semibold text-slate-900 group-hover:text-blue-700 transition-colors line-clamp-2">
                        {item.title}
                      </h3>
                      <StatusLabel status={item.status} />
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{item.date}</span>
                    </div>
                    <p className="text-sm text-slate-600 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1.5 truncate">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{item.locationZone}</span>
                    </span>
                    <span className="font-medium text-blue-700 whitespace-nowrap shrink-0">
                      View Details →
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Editorial 3-Step Verification Process */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 lg:p-10">
          <div className="max-w-2xl mb-8">
            <h2 className="text-xl font-display font-bold text-slate-900">
              How Campus Verification Works
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Designed to reunite belongings quickly while protecting student and faculty privacy.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6 border-t border-slate-200">
            <div className="space-y-2">
              <p className="text-xs font-mono font-medium text-blue-700">01. Report & Match</p>
              <h3 className="text-base font-display font-semibold text-slate-900">
                Log item details & campus zone
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Upload a photo and pin the campus building. Our matching check automatically alerts
                owners when a similar item is found.
              </p>
            </div>
            <div className="space-y-2">
              <p className="text-xs font-mono font-medium text-blue-700">02. Proof of Ownership</p>
              <h3 className="text-base font-display font-semibold text-slate-900">
                Submit private verification
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Claimants describe hidden identifiers, serial digits, or upload receipts. Only the
                finder and campus admins can review proof.
              </p>
            </div>
            <div className="space-y-2">
              <p className="text-xs font-mono font-medium text-blue-700">03. Safe Handover</p>
              <h3 className="text-base font-display font-semibold text-slate-900">
                Protected contact & return
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Message safely in-app without exposing phone numbers. Once a claim is approved, the
                item status updates to Returned.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
