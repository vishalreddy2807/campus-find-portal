import React, { useEffect, useState } from 'react';
import { deleteDoc, doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import {
  Bell,
  Check,
  CheckCircle2,
  Edit3,
  MessageSquare,
  Send,
  Trash2,
  XCircle,
} from 'lucide-react';
import {
  createRecordId,
  db,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  DEPARTMENTS,
  type CampusItem,
  type InAppMessage,
  type OwnershipClaim,
  type UserNotification,
  type UserProfile,
} from '../types/campus';
import { ItemVisual, StatusLabel } from './ItemVisual';

interface UserDashboardViewProps {
  initialTab?: string;
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  items: CampusItem[];
  claims: OwnershipClaim[];
  messages: InAppMessage[];
  notifications: UserNotification[];
  onOpenAuth: () => void;
  onEditItem: (item: CampusItem) => void;
  onSelectItem: (item: CampusItem) => void;
}

type DashTab = 'reports' | 'claims' | 'messages' | 'notifications' | 'profile';

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  initialTab,
  userProfile,
  isAuthenticated,
  items,
  claims,
  messages,
  notifications,
  onOpenAuth,
  onEditItem,
  onSelectItem,
}) => {
  const [activeTab, setActiveTab] = useState<DashTab>('reports');
  const [actionMsg, setActionMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Claim review inputs keyed by claimId
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [handoverContacts, setHandoverContacts] = useState<Record<string, string>>({});

  // Quick reply state
  const [replyTarget, setReplyTarget] = useState<InAppMessage | null>(null);
  const [replyText, setReplyText] = useState('');

  // Profile form state
  const [profileName, setProfileName] = useState(userProfile?.name || '');
  const [profileUsn, setProfileUsn] = useState(userProfile?.usn || '');
  const [profileDept, setProfileDept] = useState(userProfile?.department || DEPARTMENTS[0]);
  const [profileContact, setProfileContact] = useState(userProfile?.contact || '');
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    if (
      initialTab === 'reports' ||
      initialTab === 'claims' ||
      initialTab === 'messages' ||
      initialTab === 'notifications' ||
      initialTab === 'profile'
    ) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  useEffect(() => {
    if (userProfile) {
      setProfileName(userProfile.name);
      setProfileUsn(userProfile.usn);
      setProfileDept(userProfile.department);
      setProfileContact(userProfile.contact);
    }
  }, [userProfile]);

  if (!isAuthenticated || !userProfile) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16">
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-4">
          <h1 className="text-2xl font-display font-bold text-slate-900">
            Access Your Dashboard
          </h1>
          <p className="text-sm text-slate-600">
            Sign in to view your reported lost and found items, verify claims, read messages, and
            manage notifications.
          </p>
          <button
            type="button"
            onClick={onOpenAuth}
            className="px-5 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            Login / Register
          </button>
        </div>
      </div>
    );
  }

  const myLostItems = items.filter(
    (i) => !i.isDemoOnly && i.reporterId === userProfile.uid && i.type === 'lost'
  );
  const myFoundItems = items.filter(
    (i) => !i.isDemoOnly && i.reporterId === userProfile.uid && i.type === 'found'
  );
  const incomingClaims = claims.filter((c) => c.itemReporterId === userProfile.uid);
  const myClaims = claims.filter((c) => c.claimantId === userProfile.uid);

  const handleDeleteItem = async (itemId: string) => {
    setErrorMsg('');
    setActionMsg('');
    try {
      await deleteDoc(doc(db, 'items', itemId));
      setActionMsg('Report deleted cleanly.');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.DELETE, `items/${itemId}`);
      } catch (wrapped) {
        setErrorMsg(wrapped instanceof Error ? wrapped.message : 'Failed to delete item.');
      }
    }
  };

  const handleMarkReturned = async (item: CampusItem) => {
    setErrorMsg('');
    setActionMsg('');
    try {
      await updateDoc(doc(db, 'items', item.id), {
        status: 'Returned',
        updatedAt: serverTimestamp(),
      });
      setActionMsg(`"${item.title}" marked as Returned.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `items/${item.id}`);
      } catch (wrapped) {
        setErrorMsg(wrapped instanceof Error ? wrapped.message : 'Failed to update status.');
      }
    }
  };

  const handleClaimDecision = async (
    claim: OwnershipClaim,
    decision: 'approved' | 'rejected'
  ) => {
    setErrorMsg('');
    setActionMsg('');
    const note = (reviewNotes[claim.id] || '').trim().slice(0, 500);
    const handover =
      decision === 'approved'
        ? (
            handoverContacts[claim.id] ||
            userProfile.contact ||
            `Meet at ${userProfile.department} office or reply via In-App Messages`
          )
            .trim()
            .slice(0, 200)
        : '';

    try {
      await updateDoc(doc(db, 'claims', claim.id), {
        status: decision,
        reviewerNote: note,
        approvedContactInfo: handover,
        updatedAt: serverTimestamp(),
      });

      const targetItem = items.find((i) => i.id === claim.itemId);
      if (targetItem) {
        await updateDoc(doc(db, 'items', targetItem.id), {
          status:
            decision === 'approved'
              ? 'Returned'
              : targetItem.type === 'lost'
              ? 'Lost'
              : 'Found',
          claimedById: decision === 'approved' ? claim.claimantId : '',
          updatedAt: serverTimestamp(),
        });
      }

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: claim.claimantId,
        actorId: userProfile.uid,
        type: decision === 'approved' ? 'claim_approved' : 'claim_rejected',
        title:
          decision === 'approved'
            ? `Claim approved for "${claim.itemTitle.slice(0, 55)}"`
            : `Claim update for "${claim.itemTitle.slice(0, 55)}"`,
        message:
          decision === 'approved'
            ? `Your ownership claim was approved! Handover info: ${handover}`
            : `Your claim was not approved.${note ? ` Note: ${note}` : ''}`,
        itemId: claim.itemId,
        read: false,
        createdAt: serverTimestamp(),
      });

      setActionMsg(
        decision === 'approved'
          ? 'Claim approved and item status updated to Returned.'
          : 'Claim rejected and item reopened.'
      );
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `claims/${claim.id}`);
      } catch (wrapped) {
        setErrorMsg(wrapped instanceof Error ? wrapped.message : 'Failed to process claim.');
      }
    }
  };

  const handleMarkNotificationRead = async (notifId: string) => {
    try {
      await updateDoc(doc(db, 'notifications', notifId), { read: true });
    } catch {
      // ignore
    }
  };

  const handleMarkAllRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    await Promise.all(
      unread.map((n) => updateDoc(doc(db, 'notifications', n.id), { read: true }).catch(() => {}))
    );
  };

  const handleMarkMessageRead = async (msg: InAppMessage) => {
    if (msg.recipientId === userProfile.uid && !msg.read) {
      await updateDoc(doc(db, 'messages', msg.id), { read: true }).catch(() => {});
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyTarget || !replyText.trim()) return;
    const recipientId =
      replyTarget.senderId === userProfile.uid ? replyTarget.recipientId : replyTarget.senderId;
    const recipientName =
      replyTarget.senderId === userProfile.uid
        ? replyTarget.recipientName
        : replyTarget.senderName;

    try {
      const msgId = createRecordId('msg');
      await setDoc(doc(db, 'messages', msgId), {
        id: msgId,
        itemId: replyTarget.itemId,
        itemTitle: replyTarget.itemTitle,
        senderId: userProfile.uid,
        senderName: userProfile.name.slice(0, 100),
        recipientId,
        recipientName: recipientName.slice(0, 100),
        body: replyText.trim().slice(0, 1000),
        read: false,
        createdAt: serverTimestamp(),
      });

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: recipientId,
        actorId: userProfile.uid,
        type: 'message',
        title: `New reply about "${replyTarget.itemTitle.slice(0, 55)}"`,
        message: `${userProfile.name} replied to your message in Campus Find.`,
        itemId: replyTarget.itemId,
        read: false,
        createdAt: serverTimestamp(),
      });

      setReplyTarget(null);
      setReplyText('');
      setActionMsg('Reply sent.');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, 'messages');
      } catch (wrapped) {
        setErrorMsg(wrapped instanceof Error ? wrapped.message : 'Failed to send reply.');
      }
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim() || !profileUsn.trim()) {
      setErrorMsg('Name and USN / College ID are required.');
      return;
    }
    setSavingProfile(true);
    setErrorMsg('');
    setActionMsg('');
    try {
      await updateDoc(doc(db, 'users', userProfile.uid), {
        name: profileName.trim().slice(0, 100),
        usn: profileUsn.trim().slice(0, 40),
        department: profileDept.slice(0, 80),
        contact: profileContact.trim().slice(0, 80),
        updatedAt: serverTimestamp(),
      });
      setActionMsg('Profile updated.');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `users/${userProfile.uid}`);
      } catch (wrapped) {
        setErrorMsg(wrapped instanceof Error ? wrapped.message : 'Failed to update profile.');
      }
    } finally {
      setSavingProfile(false);
    }
  };

  const unreadNotifCount = notifications.filter((n) => !n.read).length;
  const unreadMsgCount = messages.filter(
    (m) => m.recipientId === userProfile.uid && !m.read
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900">My Campus Dashboard</h1>
          <p className="text-sm text-slate-600 mt-0.5">
            {userProfile.name} · <span className="font-mono">{userProfile.usn}</span> ·{' '}
            {userProfile.department}
          </p>
        </div>

        {/* Workspace Tab Bar */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg">
          {(
            [
              { id: 'reports', label: `Reports (${myLostItems.length + myFoundItems.length})` },
              {
                id: 'claims',
                label: `Claims (${incomingClaims.length + myClaims.length})`,
              },
              {
                id: 'messages',
                label: `Messages${unreadMsgCount > 0 ? ` (${unreadMsgCount})` : ''}`,
              },
              {
                id: 'notifications',
                label: `Alerts${unreadNotifCount > 0 ? ` (${unreadNotifCount})` : ''}`,
              },
              { id: 'profile', label: 'Profile' },
            ] as { id: DashTab; label: string }[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {actionMsg && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
          {actionMsg}
        </div>
      )}
      {errorMsg && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
          {errorMsg}
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="space-y-8">
          {/* Reported Lost */}
          <section className="space-y-3">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              My Reported Lost Items ({myLostItems.length})
            </h2>
            {myLostItems.length === 0 ? (
              <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
                You have not reported any lost items yet.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {myLostItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col"
                  >
                    <ItemVisual
                      imageUrl={item.imageUrl}
                      title={item.title}
                      category={item.category}
                      className="aspect-[4/3] w-full border-b border-slate-100"
                    />
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => onSelectItem(item)}
                            className="text-left text-sm font-display font-semibold text-slate-900 hover:text-blue-700 cursor-pointer"
                          >
                            {item.title}
                          </button>
                          <StatusLabel status={item.status} />
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {item.locationZone} · <span className="font-mono">{item.date}</span>
                        </p>
                      </div>
                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
                        {item.status !== 'Returned' && (
                          <>
                            <button
                              type="button"
                              onClick={() => onEditItem(item)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleMarkReturned(item)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Mark Returned</span>
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => void handleDeleteItem(item.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md ml-auto cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Reported Found */}
          <section className="space-y-3">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              My Reported Found Items ({myFoundItems.length})
            </h2>
            {myFoundItems.length === 0 ? (
              <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
                You have not posted any found items yet.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {myFoundItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col"
                  >
                    <ItemVisual
                      imageUrl={item.imageUrl}
                      title={item.title}
                      category={item.category}
                      className="aspect-[4/3] w-full border-b border-slate-100"
                    />
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => onSelectItem(item)}
                            className="text-left text-sm font-display font-semibold text-slate-900 hover:text-blue-700 cursor-pointer"
                          >
                            {item.title}
                          </button>
                          <StatusLabel status={item.status} />
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {item.locationZone} · <span className="font-mono">{item.date}</span>
                        </p>
                      </div>
                      <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
                        {item.status !== 'Returned' && (
                          <>
                            <button
                              type="button"
                              onClick={() => onEditItem(item)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleMarkReturned(item)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Mark Returned</span>
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => void handleDeleteItem(item.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md ml-auto cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {activeTab === 'claims' && (
        <div className="space-y-8">
          {/* Incoming Claims to Verify */}
          <section className="space-y-3">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Incoming Claims on Your Items ({incomingClaims.length})
            </h2>
            {incomingClaims.length === 0 ? (
              <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
                No one has submitted a claim on your reported items yet.
              </p>
            ) : (
              <div className="space-y-4">
                {incomingClaims.map((claim) => (
                  <div
                    key={claim.id}
                    className="bg-white border border-slate-200 rounded-xl p-5 space-y-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="text-base font-display font-semibold text-slate-900">
                          {claim.itemTitle}
                        </h3>
                        <p className="text-xs text-slate-500">
                          Claimant: {claim.claimantName} ({claim.claimantUsn} ·{' '}
                          {claim.claimantDepartment})
                        </p>
                      </div>
                      <span
                        className={`text-xs font-medium px-2.5 py-1 rounded-md border ${
                          claim.status === 'approved'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : claim.status === 'rejected'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        {claim.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 text-sm text-slate-700 space-y-2">
                      <p className="text-xs font-medium text-slate-500">Submitted Proof:</p>
                      <p>{claim.proofDescription}</p>
                      {claim.proofImageUrl && (
                        <img
                          src={claim.proofImageUrl}
                          alt="Claimant proof"
                          referrerPolicy="no-referrer"
                          className="w-40 h-28 object-cover rounded-lg border border-slate-200 mt-2"
                        />
                      )}
                    </div>

                    {claim.status === 'pending' && (
                      <div className="space-y-3 pt-2 border-t border-slate-100">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <input
                            type="text"
                            placeholder="Handover desk or contact info (shared on approval)"
                            value={handoverContacts[claim.id] || ''}
                            onChange={(e) =>
                              setHandoverContacts((prev) => ({
                                ...prev,
                                [claim.id]: e.target.value,
                              }))
                            }
                            className="px-3 py-2 text-xs border border-slate-300 rounded-lg"
                          />
                          <input
                            type="text"
                            placeholder="Optional reviewer note"
                            value={reviewNotes[claim.id] || ''}
                            onChange={(e) =>
                              setReviewNotes((prev) => ({
                                ...prev,
                                [claim.id]: e.target.value,
                              }))
                            }
                            className="px-3 py-2 text-xs border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => void handleClaimDecision(claim, 'approved')}
                            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Approve & Mark Returned</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleClaimDecision(claim, 'rejected')}
                            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            <span>Reject Claim</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* My Submitted Claims */}
          <section className="space-y-3">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              My Submitted Claims ({myClaims.length})
            </h2>
            {myClaims.length === 0 ? (
              <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
                You have not submitted any ownership claims yet.
              </p>
            ) : (
              <div className="space-y-3">
                {myClaims.map((claim) => (
                  <div
                    key={claim.id}
                    className="bg-white border border-slate-200 rounded-xl p-5 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-sm font-display font-semibold text-slate-900">
                        {claim.itemTitle}
                      </h3>
                      <span
                        className={`text-xs font-medium px-2.5 py-0.5 rounded-md border ${
                          claim.status === 'approved'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : claim.status === 'rejected'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}
                      >
                        {claim.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{claim.proofDescription}</p>
                    {claim.status === 'approved' && claim.approvedContactInfo && (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900">
                        <strong>Verified Handover Instructions:</strong> {claim.approvedContactInfo}
                      </div>
                    )}
                    {claim.reviewerNote && (
                      <p className="text-xs text-slate-500">Reviewer note: {claim.reviewerNote}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {activeTab === 'messages' && (
        <div className="space-y-4">
          <h2 className="text-lg font-display font-semibold text-slate-900">
            Safe In-App Messages ({messages.length})
          </h2>
          {messages.length === 0 ? (
            <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
              No in-app messages yet. Use "Safe In-App Message" on any item card to contact a finder
              or owner without sharing personal phone numbers.
            </p>
          ) : (
            <div className="space-y-3">
              {messages.map((msg) => {
                const isIncoming = msg.recipientId === userProfile.uid;
                return (
                  <div
                    key={msg.id}
                    onClick={() => void handleMarkMessageRead(msg)}
                    className={`bg-white border rounded-xl p-4 space-y-2 ${
                      isIncoming && !msg.read ? 'border-blue-400' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs">
                        <MessageSquare className="w-4 h-4 text-blue-700" />
                        <span className="font-semibold text-slate-900">
                          {isIncoming ? `From ${msg.senderName}` : `To ${msg.recipientName}`}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-600">{msg.itemTitle}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setReplyTarget(msg);
                          setReplyText('');
                        }}
                        className="text-xs font-medium text-blue-700 hover:underline cursor-pointer"
                      >
                        Reply
                      </button>
                    </div>
                    <p className="text-sm text-slate-700">{msg.body}</p>
                  </div>
                );
              })}
            </div>
          )}

          {replyTarget && (
            <form
              onSubmit={handleSendReply}
              className="bg-white border border-blue-200 rounded-xl p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium text-slate-800">
                  Replying regarding: <strong>{replyTarget.itemTitle}</strong>
                </p>
                <button
                  type="button"
                  onClick={() => setReplyTarget(null)}
                  className="text-xs text-slate-500 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  maxLength={1000}
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Write a safe in-app reply..."
                  className="flex-1 px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {activeTab === 'notifications' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Notifications ({notifications.length})
            </h2>
            {unreadNotifCount > 0 && (
              <button
                type="button"
                onClick={() => void handleMarkAllRead()}
                className="text-xs font-medium text-blue-700 hover:underline cursor-pointer"
              >
                Mark all as read
              </button>
            )}
          </div>

          {notifications.length === 0 ? (
            <p className="text-sm text-slate-500 bg-white border border-slate-200 rounded-xl p-6">
              You are all caught up. Alerts for matching items and claim updates will appear here.
            </p>
          ) : (
            <div className="space-y-2.5">
              {notifications.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => void handleMarkNotificationRead(notif.id)}
                  className={`bg-white border rounded-xl p-4 flex items-start justify-between gap-4 cursor-pointer ${
                    notif.read ? 'border-slate-200' : 'border-blue-400 bg-blue-50/20'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Bell
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        notif.read ? 'text-slate-400' : 'text-blue-700'
                      }`}
                    />
                    <div>
                      <p className="text-sm font-medium text-slate-900">{notif.title}</p>
                      <p className="text-xs text-slate-600 mt-0.5">{notif.message}</p>
                    </div>
                  </div>
                  {!notif.read && (
                    <span className="text-[11px] font-medium text-blue-700 whitespace-nowrap shrink-0">
                      New
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 max-w-xl">
          <h2 className="text-lg font-display font-semibold text-slate-900 mb-4">
            Account Profile
          </h2>
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  maxLength={100}
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  USN / College ID
                </label>
                <input
                  type="text"
                  required
                  maxLength={40}
                  value={profileUsn}
                  onChange={(e) => setProfileUsn(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">College Email</label>
              <input
                type="email"
                disabled
                value={userProfile.email}
                className="w-full px-3 py-2 text-sm bg-slate-50 text-slate-500 border border-slate-200 rounded-lg"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
                <select
                  value={profileDept}
                  onChange={(e) => setProfileDept(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                >
                  {DEPARTMENTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Contact Phone / Extension (Private)
                </label>
                <input
                  type="text"
                  maxLength={80}
                  value={profileContact}
                  onChange={(e) => setProfileContact(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Role: <strong className="text-slate-800 capitalize">{userProfile.role}</strong>
              </span>
              <button
                type="submit"
                disabled={savingProfile}
                className="px-5 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer disabled:opacity-60"
              >
                {savingProfile ? 'Saving...' : 'Save Profile'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
