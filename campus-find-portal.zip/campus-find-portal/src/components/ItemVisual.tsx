import React, { useState } from 'react';
import {
  AlertCircle,
  BookOpen,
  Briefcase,
  CheckCircle2,
  Clock,
  CreditCard,
  KeyRound,
  Laptop,
  Package,
  SearchCheck,
  Smartphone,
  Wallet,
} from 'lucide-react';
import type { ItemCategory, ItemStatus } from '../types/campus';

const CATEGORY_ICON_MAP: Record<ItemCategory, React.FC<{ className?: string }>> = {
  Mobile: Smartphone,
  Laptop: Laptop,
  'ID Card': CreditCard,
  Wallet: Wallet,
  Books: BookOpen,
  Keys: KeyRound,
  Accessories: Briefcase,
  Other: Package,
};

export const ItemVisual: React.FC<{
  imageUrl?: string;
  title: string;
  category: ItemCategory;
  className?: string;
}> = ({ imageUrl, title, category, className = '' }) => {
  const [failed, setFailed] = useState(false);
  const Icon = CATEGORY_ICON_MAP[category] || Package;

  if (imageUrl && !failed) {
    return (
      <div className={`relative overflow-hidden bg-slate-100 ${className}`}>
        <img
          src={imageUrl}
          alt={title}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
        />
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden bg-gradient-to-br from-slate-100 via-slate-50 to-blue-50/70 flex flex-col items-center justify-center p-6 text-center ${className}`}
    >
      <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-blue-700 mb-2">
        <Icon className="w-6 h-6" />
      </div>
      <span className="text-xs font-medium text-slate-600">{category}</span>
    </div>
  );
};

export const StatusLabel: React.FC<{ status: ItemStatus }> = ({ status }) => {
  switch (status) {
    case 'Lost':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-md px-2 py-0.5 whitespace-nowrap shrink-0">
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Lost</span>
        </span>
      );
    case 'Found':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-md px-2 py-0.5 whitespace-nowrap shrink-0">
          <SearchCheck className="w-3.5 h-3.5" />
          <span>Found</span>
        </span>
      );
    case 'Claim Pending':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-md px-2 py-0.5 whitespace-nowrap shrink-0">
          <Clock className="w-3.5 h-3.5" />
          <span>Claim Pending</span>
        </span>
      );
    case 'Returned':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-2 py-0.5 whitespace-nowrap shrink-0">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Returned</span>
        </span>
      );
  }
};
