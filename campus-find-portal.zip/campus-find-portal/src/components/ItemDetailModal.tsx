import React, { useState } from 'react';
import { doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import {
  AlertCircle,
  Calendar,
  CheckCircle2,
  ImagePlus,
  MapPin,
  MessageSquare,
  ShieldCheck,
  User,
  X,
} from 'lucide-react';
import {
  createRecordId,
  db,
  handleFirestoreError,
  OperationType,
  uploadImageFile,
} from '../lib/firebase';
import type { CampusItem, UserProfile } from '../types/campus';
import { ItemVisual, StatusLabel } from './ItemVisual';

interface ItemDetailModalProps {
  item: CampusItem | null;
  onClose: () => void;
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  onOpenAuth: () => void;
}

export const ItemDetailModal: React.FC<ItemDetailModalProps> = ({
  item,
  onClose,
  userProfile,
  isAuthenticated,
  onOpenAuth,
}) => {
  const [activeTab, setActiveTab] = useState<'details' | 'claim' | 'contact'>('details');
  const [proofDescription, setProofDescription] = useState('');
  const [proofImageUrl, setProofImageUrl] = useState('');
  const [uploadingProof, setUploadingProof] = useState(false);
  const [messageBody, setMessageBody] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!item) return null;

  const isOwnReport = Boolean(userProfile && userProfile.uid === item.reporterId);
  const canClaim =
    !item.isDemoOnly &&
    !isOwnReport &&
    (item.status === 'Found' || item.status === 'Lost');

  const handleUploadProof = async (file: File | undefined) => {
    if (!file) return;
    setError('');
    setUploadingProof(true);
    try {
      const url = await uploadImageFile(file);
      setProofImageUrl(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload proof image.');
    } finally {
      setUploadingProof(false);
    }
  };

  const handleClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated || !userProfile) {
      onOpenAuth();
      return;
    }
    if (userProfile.accountStatus === 'suspended') {
      setError('Your account is currently suspended.');
      return;
    }
    if (proofDescription.trim().length < 10) {
      setError('Please provide at least 10 characters describing proof of ownership.');
      return;
    }

    setError('');
    setSuccessMsg('');
    setSubmitting(true);
    try {
      const claimId = createRecordId('claim');
      await setDoc(doc(db, 'claims', claimId), {
        id: claimId,
        itemId: item.id,
        itemTitle: item.title.slice(0, 120),
        itemType: item.type,
        itemReporterId: item.reporterId,
        claimantId: userProfile.uid,
        claimantName: userProfile.name.slice(0, 100),
        claimantUsn: userProfile.usn.slice(0, 40),
        claimantDepartment: userProfile.department.slice(0, 80),
        proofDescription: proofDescription.trim().slice(0, 1000),
        proofImageUrl: proofImageUrl.slice(0, 500),
        status: 'pending',
        reviewerNote: '',
        approvedContactInfo: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await updateDoc(doc(db, 'items', item.id), {
        status: 'Claim Pending',
        claimedById: userProfile.uid,
        updatedAt: serverTimestamp(),
      });

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: item.reporterId,
        actorId: userProfile.uid,
        type: 'claim_received',
        title: `New claim submitted for "${item.title.slice(0, 55)}"`,
        message: `${userProfile.name} (${userProfile.usn}) submitted ownership proof. Review it in My Reports.`,
        itemId: item.id,
        read: false,
        createdAt: serverTimestamp(),
      });

      setProofDescription('');
      setProofImageUrl('');
      setSuccessMsg(
        'Your ownership claim has been submitted. The finder and campus administrators have been notified.'
      );
      setActiveTab('details');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, 'claims');
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to submit claim.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated || !userProfile) {
      onOpenAuth();
      return;
    }
    if (isOwnReport) {
      setError('You cannot send an inquiry to your own report.');
      return;
    }
    if (item.isDemoOnly) {
      setError('Sample preview items cannot receive live messages. Sign in as admin to seed interactive records or post a new report.');
      return;
    }
    if (!messageBody.trim()) {
      setError('Please write a message.');
      return;
    }

    setError('');
    setSuccessMsg('');
    setSubmitting(true);
    try {
      const msgId = createRecordId('msg');
      await setDoc(doc(db, 'messages', msgId), {
        id: msgId,
        itemId: item.id,
        itemTitle: item.title.slice(0, 120),
        senderId: userProfile.uid,
        senderName: userProfile.name.slice(0, 100),
        recipientId: item.reporterId,
        recipientName: item.reporterName.slice(0, 100),
        body: messageBody.trim().slice(0, 1000),
        read: false,
        createdAt: serverTimestamp(),
      });

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: item.reporterId,
        actorId: userProfile.uid,
        type: 'message',
        title: `New inquiry about "${item.title.slice(0, 55)}"`,
        message: `${userProfile.name} sent you a safe in-app message.`,
        itemId: item.id,
        read: false,
        createdAt: serverTimestamp(),
      });

      setMessageBody('');
      setSuccessMsg('In-app message sent! Replies will appear in My Reports → Messages.');
      setActiveTab('details');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, 'messages');
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to send message.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-[2px] p-4">
      <div className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-xl">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <StatusLabel status={item.status} />
            <h2 className="text-base sm:text-lg font-display font-semibold text-slate-900 truncate">
              {item.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close item details"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 flex items-start gap-2.5 text-xs text-emerald-800">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Tab Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => {
                setActiveTab('details');
                setError('');
              }}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'details'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Item Details
            </button>
            <button
              type="button"
              onClick={() => {
                if (!isAuthenticated) {
                  onOpenAuth();
                  return;
                }
                setActiveTab('claim');
                setError('');
              }}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'claim'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Claim Ownership
            </button>
            <button
              type="button"
              onClick={() => {
                if (!isAuthenticated) {
                  onOpenAuth();
                  return;
                }
                setActiveTab('contact');
                setError('');
              }}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'contact'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Safe In-App Message
            </button>
          </div>

          {activeTab === 'details' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-start">
                <ItemVisual
                  imageUrl={item.imageUrl}
                  title={item.title}
                  category={item.category}
                  className="sm:col-span-5 aspect-[4/3] w-full rounded-xl border border-slate-200"
                />
                <div className="sm:col-span-7 space-y-3">
                  <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                    <span className="font-medium text-slate-700">
                      {item.type === 'lost' ? 'Reported Lost' : 'Reported Found'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{item.category}</span>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed">{item.description}</p>

                  <div className="pt-2 space-y-2 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-blue-700 shrink-0" />
                      <span>
                        <strong className="text-slate-900">{item.locationZone}</strong> —{' '}
                        {item.location}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-blue-700 shrink-0" />
                      <span className="font-mono tabular-nums">{item.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-700 shrink-0" />
                      <span>
                        {item.reporterName} ({item.reporterDepartment})
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                      <span>Handover preference: {item.contactPreference || 'In-App Message'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {!isOwnReport && item.status !== 'Returned' && (
                <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (!isAuthenticated) {
                        onOpenAuth();
                        return;
                      }
                      setActiveTab('contact');
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Message {item.type === 'found' ? 'Finder' : 'Owner'}</span>
                  </button>

                  {canClaim && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!isAuthenticated) {
                          onOpenAuth();
                          return;
                        }
                        setActiveTab('claim');
                      }}
                      className="px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                    >
                      Submit Ownership Claim
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'claim' && (
            <form onSubmit={handleClaimSubmit} className="space-y-4">
              {item.isDemoOnly ? (
                <p className="text-sm text-slate-600 bg-slate-50 border border-slate-200 rounded-lg p-4">
                  This is a demonstration item preview. Sign in as administrator to seed live
                  database items, or post a real Found item to test full claiming.
                </p>
              ) : isOwnReport ? (
                <p className="text-sm text-slate-600 bg-slate-50 border border-slate-200 rounded-lg p-4">
                  You posted this report. Review incoming claims from other campus members under My
                  Reports.
                </p>
              ) : item.status === 'Returned' ? (
                <p className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  This item has already been verified and returned to its owner.
                </p>
              ) : item.status === 'Claim Pending' ? (
                <p className="text-sm text-amber-900 bg-amber-50 border border-amber-200 rounded-lg p-4">
                  A verification claim is currently under review for this item. You can still send a
                  safe in-app message to the reporter if needed.
                </p>
              ) : (
                <>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Provide clear proof of ownership (unique stickers, wallpaper, serial digits,
                    contents inside wallet/bag, or receipt). Only the reporter and campus
                    administrators can inspect your proof.
                  </p>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Proof of Ownership *
                    </label>
                    <textarea
                      required
                      minLength={10}
                      maxLength={1000}
                      rows={4}
                      value={proofDescription}
                      onChange={(e) => setProofDescription(e.target.value)}
                      placeholder="Describe specific identifying features, contents, or serial suffix..."
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Supporting Proof Photo / Receipt (Optional)
                    </label>
                    {proofImageUrl ? (
                      <div className="flex items-center gap-3">
                        <img
                          src={proofImageUrl}
                          alt="Proof preview"
                          referrerPolicy="no-referrer"
                          className="w-20 h-16 object-cover rounded-lg border border-slate-200"
                        />
                        <button
                          type="button"
                          onClick={() => setProofImageUrl('')}
                          className="text-xs text-rose-700 hover:underline cursor-pointer"
                        >
                          Remove image
                        </button>
                      </div>
                    ) : (
                      <label className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg cursor-pointer">
                        <ImagePlus className="w-4 h-4 text-blue-700" />
                        <span>{uploadingProof ? 'Uploading...' : 'Attach Proof Image'}</span>
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp,image/gif"
                          className="hidden"
                          disabled={uploadingProof}
                          onChange={(e) => void handleUploadProof(e.target.files?.[0])}
                        />
                      </label>
                    )}
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="submit"
                      disabled={submitting || uploadingProof}
                      className="px-5 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer disabled:opacity-60"
                    >
                      {submitting ? 'Submitting Claim...' : 'Submit Verification Claim'}
                    </button>
                  </div>
                </>
              )}
            </form>
          )}

          {activeTab === 'contact' && (
            <form onSubmit={handleMessageSubmit} className="space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Send a message directly to <strong>{item.reporterName}</strong> inside Campus Find.
                Your email address and phone number are never exposed automatically.
              </p>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Your Message *
                </label>
                <textarea
                  required
                  maxLength={1000}
                  rows={4}
                  value={messageBody}
                  onChange={(e) => setMessageBody(e.target.value)}
                  placeholder="Ask about the exact desk location, condition, or arrange a safe campus handover..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={submitting || isOwnReport}
                  className="px-5 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer disabled:opacity-60"
                >
                  {submitting ? 'Sending...' : 'Send Safe In-App Message'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
