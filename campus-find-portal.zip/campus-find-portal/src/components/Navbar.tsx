import React, { useState } from 'react';
import { Bell, LogIn, Menu, ShieldCheck, User, X } from 'lucide-react';
import type { UserProfile } from '../types/campus';

export type ActivePage =
  | 'home'
  | 'lost'
  | 'found'
  | 'report'
  | 'dashboard'
  | 'admin';

interface NavbarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage, options?: { reportType?: 'lost' | 'found'; dashTab?: string }) => void;
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  unreadNotifications: number;
  unreadMessages: number;
  onOpenAuth: () => void;
  onSignOut: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  onNavigate,
  userProfile,
  isAuthenticated,
  isAdmin,
  unreadNotifications,
  unreadMessages,
  onOpenAuth,
  onSignOut,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const totalUnread = unreadNotifications + unreadMessages;

  const navItems: { id: ActivePage; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'lost', label: 'Lost Items' },
    { id: 'found', label: 'Found Items' },
    { id: 'report', label: 'Report Item' },
    { id: 'dashboard', label: 'My Reports' },
  ];

  const handleNav = (id: ActivePage) => {
    setMobileOpen(false);
    setMenuOpen(false);
    onNavigate(id);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('home')}
          className="text-lg font-display font-bold tracking-tight text-slate-900 hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          Campus Find
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          {navItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
                  isActive
                    ? 'text-blue-700 border-blue-700'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
          {isAdmin && (
            <button
              type="button"
              onClick={() => handleNav('admin')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
                activePage === 'admin'
                  ? 'text-blue-700 border-blue-700'
                  : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              Admin
            </button>
          )}
        </nav>

        {/* Zone 3: Single primary action area */}
        <div className="flex items-center gap-3 shrink-0">
          {!isAuthenticated ? (
            <button
              type="button"
              onClick={onOpenAuth}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Login / Register</span>
            </button>
          ) : (
            <div className="relative flex items-center gap-2">
              <button
                type="button"
                onClick={() => onNavigate('dashboard', { dashTab: 'notifications' })}
                aria-label="View notifications"
                className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {totalUnread > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 flex items-center justify-center text-[11px] font-mono font-medium text-white bg-blue-700 rounded-full tabular-nums">
                    {totalUnread > 9 ? '9+' : totalUnread}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setMenuOpen((prev) => !prev)}
                className="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <User className="w-4 h-4 text-blue-700" />
                <span className="max-w-[140px] truncate">
                  {userProfile?.name || 'Account'}
                </span>
              </button>

              {menuOpen && (
                <div className="absolute right-0 top-12 w-60 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="text-sm font-semibold text-slate-900 truncate">
                      {userProfile?.name || 'Campus Member'}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {userProfile?.usn || userProfile?.email}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onNavigate('dashboard', { dashTab: 'reports' });
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    My Reports & Claims
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onNavigate('dashboard', { dashTab: 'messages' });
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center justify-between cursor-pointer"
                  >
                    <span>In-App Messages</span>
                    {unreadMessages > 0 && (
                      <span className="text-xs font-mono font-medium text-blue-700 tabular-nums">
                        {unreadMessages} new
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onNavigate('dashboard', { dashTab: 'profile' });
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 cursor-pointer"
                  >
                    Profile Settings
                  </button>
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        onNavigate('admin');
                      }}
                      className="w-full text-left px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50 flex items-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Admin Dashboard</span>
                    </button>
                  )}
                  <div className="my-1 border-t border-slate-100" />
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onSignOut();
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-red-700 hover:bg-red-50 cursor-pointer"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label="Toggle navigation menu"
            className="md:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleNav(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium cursor-pointer ${
                activePage === item.id
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              {item.label}
            </button>
          ))}
          {isAdmin && (
            <button
              type="button"
              onClick={() => handleNav('admin')}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium cursor-pointer ${
                activePage === 'admin'
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              Admin Dashboard
            </button>
          )}
          <div className="pt-2 border-t border-slate-100">
            {!isAuthenticated ? (
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenAuth();
                }}
                className="w-full py-2.5 px-4 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
              >
                Login / Register
              </button>
            ) : (
              <div className="flex items-center justify-between px-3 py-2">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900 truncate">
                    {userProfile?.name || 'Member'}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{userProfile?.usn}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onSignOut();
                  }}
                  className="text-sm font-medium text-red-700 hover:underline cursor-pointer"
                >
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
