import React, { useMemo, useState } from 'react';
import { deleteDoc, doc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import {
  CheckCircle2,
  Database,
  ShieldAlert,
  Trash2,
  Users,
  XCircle,
} from 'lucide-react';
import {
  createRecordId,
  db,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  ITEM_CATEGORIES,
  SAMPLE_CAMPUS_ITEMS,
  type CampusItem,
  type OwnershipClaim,
  type UserProfile,
  type UserRole,
} from '../types/campus';

interface AdminDashboardViewProps {
  adminProfile: UserProfile;
  items: CampusItem[];
  claims: OwnershipClaim[];
  users: UserProfile[];
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  adminProfile,
  items,
  claims,
  users,
}) => {
  const [tab, setTab] = useState<'overview' | 'items' | 'claims' | 'users'>('overview');
  const [itemSearch, setItemSearch] = useState('');
  const [modFilter, setModFilter] = useState<'all' | 'approved' | 'pending' | 'rejected'>('all');
  const [userSearch, setUserSearch] = useState('');
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const [seeding, setSeeding] = useState(false);

  const realItems = useMemo(() => items.filter((i) => !i.isDemoOnly), [items]);
  const pendingClaims = useMemo(() => claims.filter((c) => c.status === 'pending'), [claims]);
  const returnedItems = useMemo(
    () => realItems.filter((i) => i.status === 'Returned'),
    [realItems]
  );

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    ITEM_CATEGORIES.forEach((c) => {
      counts[c] = 0;
    });
    realItems.forEach((item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return counts;
  }, [realItems]);

  const maxCatCount = Math.max(1, ...Object.values(categoryCounts));

  const filteredItems = useMemo(() => {
    const q = itemSearch.trim().toLowerCase();
    return realItems
      .filter((i) => (modFilter === 'all' ? true : i.moderationStatus === modFilter))
      .filter((i) =>
        q
          ? i.title.toLowerCase().includes(q) ||
            i.reporterName.toLowerCase().includes(q) ||
            i.locationZone.toLowerCase().includes(q)
          : true
      );
  }, [realItems, modFilter, itemSearch]);

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    return users.filter((u) =>
      q
        ? u.name.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.usn.toLowerCase().includes(q) ||
          u.department.toLowerCase().includes(q)
        : true
    );
  }, [users, userSearch]);

  const handleSeedSamples = async () => {
    setSeeding(true);
    setError('');
    setFeedback('');
    try {
      for (const sample of SAMPLE_CAMPUS_ITEMS) {
        await setDoc(doc(db, 'items', sample.id), {
          ...sample,
          reporterId: adminProfile.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      setFeedback(`Loaded ${SAMPLE_CAMPUS_ITEMS.length} sample lost & found items into Firestore.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.CREATE, 'items');
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to seed sample items.');
      }
    } finally {
      setSeeding(false);
    }
  };

  const handleModerateItem = async (
    item: CampusItem,
    moderationStatus: 'approved' | 'rejected'
  ) => {
    setError('');
    setFeedback('');
    try {
      await updateDoc(doc(db, 'items', item.id), {
        moderationStatus,
        updatedAt: serverTimestamp(),
      });

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: item.reporterId,
        actorId: adminProfile.uid,
        type: 'moderation',
        title: `Report ${moderationStatus}: "${item.title.slice(0, 50)}"`,
        message:
          moderationStatus === 'approved'
            ? 'Your report has been approved by campus administrators.'
            : 'Your report was flagged or rejected by campus moderation.',
        itemId: item.id,
        read: false,
        createdAt: serverTimestamp(),
      });

      setFeedback(`Updated moderation status to ${moderationStatus}.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `items/${item.id}`);
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Moderation update failed.');
      }
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    setError('');
    setFeedback('');
    try {
      await deleteDoc(doc(db, 'items', itemId));
      setFeedback('Item report removed permanently.');
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.DELETE, `items/${itemId}`);
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Delete failed.');
      }
    }
  };

  const handleAdminClaimDecision = async (
    claim: OwnershipClaim,
    decision: 'approved' | 'rejected'
  ) => {
    setError('');
    setFeedback('');
    try {
      const handover =
        decision === 'approved'
          ? 'Verified by Campus Find Admin — collect from Administrative Block Security Desk with valid College ID.'
          : '';
      await updateDoc(doc(db, 'claims', claim.id), {
        status: decision,
        reviewerNote: `Reviewed by Campus Admin (${adminProfile.name})`,
        approvedContactInfo: handover,
        updatedAt: serverTimestamp(),
      });

      const targetItem = realItems.find((i) => i.id === claim.itemId);
      if (targetItem) {
        await updateDoc(doc(db, 'items', targetItem.id), {
          status:
            decision === 'approved'
              ? 'Returned'
              : targetItem.type === 'lost'
              ? 'Lost'
              : 'Found',
          claimedById: decision === 'approved' ? claim.claimantId : '',
          updatedAt: serverTimestamp(),
        });
      }

      const notifId = createRecordId('notif');
      await setDoc(doc(db, 'notifications', notifId), {
        id: notifId,
        userId: claim.claimantId,
        actorId: adminProfile.uid,
        type: decision === 'approved' ? 'claim_approved' : 'claim_rejected',
        title: `Admin ${decision} your claim for "${claim.itemTitle.slice(0, 45)}"`,
        message:
          decision === 'approved'
            ? handover
            : 'Please contact Campus Security Lost & Found Desk for further review.',
        itemId: claim.itemId,
        read: false,
        createdAt: serverTimestamp(),
      });

      setFeedback(`Claim ${decision}.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `claims/${claim.id}`);
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Claim update failed.');
      }
    }
  };

  const handleUpdateUserRole = async (targetUser: UserProfile, newRole: UserRole) => {
    setError('');
    setFeedback('');
    try {
      await updateDoc(doc(db, 'users', targetUser.uid), {
        role: newRole,
        updatedAt: serverTimestamp(),
      });
      if (newRole === 'admin') {
        await setDoc(doc(db, 'admins', targetUser.uid), {
          uid: targetUser.uid,
          grantedBy: adminProfile.uid,
          createdAt: serverTimestamp(),
        });
      }
      setFeedback(`Updated ${targetUser.name} role to ${newRole}.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `users/${targetUser.uid}`);
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to update role.');
      }
    }
  };

  const handleToggleSuspend = async (targetUser: UserProfile) => {
    if (targetUser.uid === adminProfile.uid) {
      setError('You cannot suspend your own administrator account.');
      return;
    }
    const nextStatus = targetUser.accountStatus === 'active' ? 'suspended' : 'active';
    setError('');
    setFeedback('');
    try {
      await updateDoc(doc(db, 'users', targetUser.uid), {
        accountStatus: nextStatus,
        updatedAt: serverTimestamp(),
      });
      setFeedback(`${targetUser.name} is now ${nextStatus}.`);
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.UPDATE, `users/${targetUser.uid}`);
      } catch (wrapped) {
        setError(wrapped instanceof Error ? wrapped.message : 'Failed to update account status.');
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900">
            Campus Find Administration
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Moderate reports, verify ownership claims, and manage student & faculty accounts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-100 border border-slate-200 rounded-lg">
            {(
              [
                { id: 'overview', label: 'Overview' },
                { id: 'items', label: `Reports (${realItems.length})` },
                { id: 'claims', label: `Claims (${claims.length})` },
                { id: 'users', label: `Accounts (${users.length})` },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  tab === t.id ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            disabled={seeding}
            onClick={() => void handleSeedSamples()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
          >
            <Database className="w-3.5 h-3.5" />
            <span>{seeding ? 'Seeding...' : 'Load Sample Items'}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
          {feedback}
        </div>
      )}
      {error && (
        <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
          {error}
        </div>
      )}

      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <p className="text-xs text-slate-500">Registered Accounts</p>
              <p className="mt-1 text-2xl font-display font-bold text-slate-900 tabular-nums">
                {users.length}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <p className="text-xs text-slate-500">Live Reports</p>
              <p className="mt-1 text-2xl font-display font-bold text-blue-700 tabular-nums">
                {realItems.length}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <p className="text-xs text-slate-500">Pending Claims</p>
              <p className="mt-1 text-2xl font-display font-bold text-amber-700 tabular-nums">
                {pendingClaims.length}
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-5">
              <p className="text-xs text-slate-500">Verified Returns</p>
              <p className="mt-1 text-2xl font-display font-bold text-emerald-700 tabular-nums">
                {returnedItems.length}
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <h2 className="text-base font-display font-semibold text-slate-900">
              Reports by Category
            </h2>
            <div className="space-y-3">
              {ITEM_CATEGORIES.map((cat) => {
                const count = categoryCounts[cat] || 0;
                const pct = Math.round((count / maxCatCount) * 100);
                return (
                  <div key={cat} className="grid grid-cols-12 items-center gap-3 text-xs">
                    <span className="col-span-3 sm:col-span-2 text-slate-700 font-medium truncate">
                      {cat}
                    </span>
                    <div className="col-span-7 sm:col-span-9 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-700 rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="col-span-2 sm:col-span-1 text-right font-mono tabular-nums text-slate-700">
                      {count}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {tab === 'items' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row gap-3 justify-between">
            <input
              type="text"
              value={itemSearch}
              onChange={(e) => setItemSearch(e.target.value)}
              placeholder="Search reports by title, reporter, or zone..."
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg sm:w-72"
            />
            <select
              value={modFilter}
              onChange={(e) =>
                setModFilter(e.target.value as 'all' | 'approved' | 'pending' | 'rejected')
              }
              className="px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
            >
              <option value="all">All Moderation States</option>
              <option value="approved">Approved</option>
              <option value="pending">Pending Review</option>
              <option value="rejected">Rejected / Flagged</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-medium">Item</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Reporter</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Moderation</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                      No live database reports match your filters. Click "Load Sample Items" to
                      populate initial records.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{item.title}</p>
                        <p className="text-slate-500">
                          {item.category} · {item.locationZone}
                        </p>
                      </td>
                      <td className="px-4 py-3 uppercase font-mono text-slate-700">{item.type}</td>
                      <td className="px-4 py-3 text-slate-700">{item.reporterName}</td>
                      <td className="px-4 py-3 text-slate-700">{item.status}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded border text-[11px] font-medium ${
                            item.moderationStatus === 'approved'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : item.moderationStatus === 'rejected'
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : 'bg-amber-50 text-amber-800 border-amber-200'
                          }`}
                        >
                          {item.moderationStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap space-x-2">
                        {item.moderationStatus !== 'approved' && (
                          <button
                            type="button"
                            onClick={() => void handleModerateItem(item, 'approved')}
                            className="text-emerald-700 hover:underline font-medium cursor-pointer"
                          >
                            Approve
                          </button>
                        )}
                        {item.moderationStatus !== 'rejected' && (
                          <button
                            type="button"
                            onClick={() => void handleModerateItem(item, 'rejected')}
                            className="text-amber-800 hover:underline font-medium cursor-pointer"
                          >
                            Reject
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => void handleDeleteItem(item.id)}
                          className="text-rose-700 hover:underline font-medium inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'claims' && (
        <div className="space-y-3">
          {claims.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
              No ownership claims have been filed yet.
            </div>
          ) : (
            claims.map((claim) => (
              <div
                key={claim.id}
                className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-display font-semibold text-slate-900">
                      {claim.itemTitle}
                    </h3>
                    <span className="text-xs font-mono text-slate-500">({claim.status})</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    Claimant: {claim.claimantName} · {claim.claimantUsn} ·{' '}
                    {claim.claimantDepartment}
                  </p>
                  <p className="text-xs text-slate-700 bg-slate-50 border border-slate-200 rounded p-2 mt-1">
                    {claim.proofDescription}
                  </p>
                </div>

                {claim.status === 'pending' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => void handleAdminClaimDecision(claim, 'approved')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleAdminClaimDecision(claim, 'rejected')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'users' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Users className="w-4 h-4 text-blue-700" />
              <span>Student & Faculty Accounts</span>
            </div>
            <input
              type="text"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Search name, USN, email..."
              className="px-3 py-1.5 text-sm border border-slate-300 rounded-lg sm:w-64"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="px-4 py-3 font-medium">Member</th>
                  <th className="px-4 py-3 font-medium">USN / ID</th>
                  <th className="px-4 py-3 font-medium">Department</th>
                  <th className="px-4 py-3 font-medium">Role</th>
                  <th className="px-4 py-3 font-medium">Account Status</th>
                  <th className="px-4 py-3 font-medium text-right">Manage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map((u) => (
                  <tr key={u.uid} className="hover:bg-slate-50/70">
                    <td className="px-4 py-3">
                      <p className="font-medium text-slate-900">{u.name}</p>
                      <p className="text-slate-500">{u.email}</p>
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-700">{u.usn}</td>
                    <td className="px-4 py-3 text-slate-700">{u.department}</td>
                    <td className="px-4 py-3">
                      <select
                        aria-label={`Role for ${u.name}`}
                        value={u.role}
                        onChange={(e) => void handleUpdateUserRole(u, e.target.value as UserRole)}
                        className="px-2 py-1 border border-slate-300 rounded bg-white text-slate-800"
                      >
                        <option value="student">student</option>
                        <option value="faculty">faculty</option>
                        <option value="admin">admin</option>
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded border text-[11px] font-medium ${
                          u.accountStatus === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}
                      >
                        {u.accountStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => void handleToggleSuspend(u)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-slate-700 hover:text-rose-700 cursor-pointer"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>{u.accountStatus === 'active' ? 'Suspend' : 'Activate'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
